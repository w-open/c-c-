#include <stdio.h>
void main()
{
	printf("this is a C program. \n");
}